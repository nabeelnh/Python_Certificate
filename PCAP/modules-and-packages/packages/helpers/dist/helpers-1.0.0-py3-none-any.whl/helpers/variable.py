import string  

name = input("What's your name? ")